package com.example.engine

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ExecutionResult(
    val success: Boolean,
    val outputLog: List<LogEntry>,
    val executionTimeMs: Long,
    val variablesState: Map<String, String> = emptyMap()
)

data class LogEntry(
    val type: LogType,
    val text: String,
    val timestamp: String = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())
)

enum class LogType {
    INFO, PRINT, WARN, ERROR, SUCCESS, SYSTEM
}

object LuaInterpreterEngine {

    fun validateSyntax(code: String): Pair<Boolean, String?> {
        if (code.isBlank()) return Pair(false, "Mã nguồn trống")

        val lines = code.lines()
        var blockDepth = 0
        var stringQuoteChar: Char? = null
        var inComment = false

        for ((index, rawLine) in lines.withIndex()) {
            val lineNum = index + 1
            val trimmed = rawLine.trim()

            if (trimmed.startsWith("--[[")) {
                inComment = true
            }
            if (inComment) {
                if (trimmed.contains("]]")) {
                    inComment = false
                }
                continue
            }
            if (trimmed.startsWith("--")) continue

            // Count block openers/closers keywords
            val words = trimmed.split(Regex("\\s+|(?=[(),{}])|(?<=[(),{}])"))
            for (word in words) {
                when (word) {
                    "function", "then", "do", "repeat" -> blockDepth++
                    "end", "until" -> blockDepth--
                }
            }

            if (blockDepth < 0) {
                return Pair(false, "Cú pháp lỗi ở dòng $lineNum: Thừa từ khóa 'end' hoặc 'until'")
            }
        }

        if (blockDepth > 0) {
            return Pair(false, "Cú pháp thiếu 'end' đóng khối lệnh (thiếu $blockDepth khối 'end')")
        }

        return Pair(true, null)
    }

    fun executeLuaScript(code: String): ExecutionResult {
        val startTime = System.currentTimeMillis()
        val logs = mutableListOf<LogEntry>()
        val variables = mutableMapOf<String, String>()

        logs.add(LogEntry(LogType.SYSTEM, "--- Khởi động Lua Execution Environment (Delta Sandbox v3.5) ---"))

        val syntaxCheck = validateSyntax(code)
        if (!syntaxCheck.first) {
            logs.add(LogEntry(LogType.ERROR, "Kiểm tra cú pháp thất bại: ${syntaxCheck.second}"))
            return ExecutionResult(false, logs, System.currentTimeMillis() - startTime)
        }

        logs.add(LogEntry(LogType.SUCCESS, "✓ Đã kiểm tra cú pháp thành công"))

        val lines = code.lines()
        var mockPlayerHealth = 100
        var mockCoins = 500

        try {
            for ((idx, line) in lines.withIndex()) {
                val trimmed = line.trim()
                if (trimmed.isEmpty() || trimmed.startsWith("--")) continue

                // Handle print statements
                if (trimmed.startsWith("print(") && trimmed.endsWith(")")) {
                    val content = trimmed.substring(6, trimmed.length - 1)
                        .replace("\"", "")
                        .replace("'", "")
                    logs.add(LogEntry(LogType.PRINT, "[PRINT]: $content"))
                } else if (trimmed.contains("print(")) {
                    val printRegex = Regex("""print\((.*?)\)""")
                    printRegex.findAll(trimmed).forEach { match ->
                        val text = match.groupValues[1].replace("\"", "").replace("'", "")
                        logs.add(LogEntry(LogType.PRINT, "[PRINT]: $text"))
                    }
                }

                // Handle variable declarations
                if (trimmed.contains(" = ") && !trimmed.startsWith("if") && !trimmed.startsWith("while")) {
                    val parts = trimmed.replace("local ", "").split(" = ", limit = 2)
                    if (parts.size == 2) {
                        val varName = parts[0].trim()
                        val varVal = parts[1].trim()
                        variables[varName] = varVal
                        logs.add(LogEntry(LogType.INFO, "Gán biến: $varName = $varVal"))
                    }
                }

                // Handle Roblox Service simulation
                if (trimmed.contains("game:GetService")) {
                    val serviceName = Regex("""game:GetService\("([^"]+)"\)""")
                        .find(trimmed)?.groupValues?.get(1) ?: "Service"
                    logs.add(LogEntry(LogType.INFO, "Tải Roblox Service: [$serviceName]"))
                }

                // Handle Delta / Rayfield / Orion GUI libraries
                if (trimmed.contains("OrionLib:MakeWindow") || trimmed.contains("Rayfield:CreateWindow") || trimmed.contains("Fluent:CreateWindow")) {
                    val guiType = if (trimmed.contains("Orion")) "Orion UI" else if (trimmed.contains("Rayfield")) "Rayfield UI" else "Fluent UI"
                    logs.add(LogEntry(LogType.SUCCESS, "🎮 Đã khởi tạo $guiType Window trên thiết bị di động"))
                }

                if (trimmed.contains("setclipboard")) {
                    logs.add(LogEntry(LogType.WARN, "📋 SetClipboard: Đã sao chép link/key vào khay nhớ tạm"))
                }

                if (trimmed.contains("task.wait")) {
                    val waitTime = Regex("""task\.wait\((.*?)\)""").find(trimmed)?.groupValues?.get(1) ?: "1"
                    logs.add(LogEntry(LogType.INFO, "⏱ task.wait($waitTime) - Đang chờ $waitTime giây..."))
                }
            }

            logs.add(LogEntry(LogType.SUCCESS, "✓ Đã thực thi script thành công mà không có sự cố!"))
            val endTime = System.currentTimeMillis() - startTime
            return ExecutionResult(true, logs, endTime, variables)

        } catch (e: Exception) {
            logs.add(LogEntry(LogType.ERROR, "Lỗi thực thi runtime: ${e.message}"))
            return ExecutionResult(false, logs, System.currentTimeMillis() - startTime)
        }
    }
}
