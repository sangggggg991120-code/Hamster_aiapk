package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.LogType
import com.example.ui.theme.CodeEditorBackground
import com.example.ui.theme.CyberEmeraldSecondary
import com.example.ui.theme.CyberVioletPrimary
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ErrorRed
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LuaWorkbenchScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val code by viewModel.workbenchCode.collectAsState()
    val outputResult by viewModel.workbenchOutput.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Terminal,
                            contentDescription = null,
                            tint = CyberEmeraldSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Lua Sandbox Workbench",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.copyToClipboard(code) },
                        modifier = Modifier.testTag("btn_workbench_copy")
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Sao chép", tint = Color.White)
                    }
                    IconButton(
                        onClick = { viewModel.exportScriptToFile("Workbench_Script", code) },
                        modifier = Modifier.testTag("btn_workbench_export")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = "Xuất file", tint = Color.White)
                    }
                    IconButton(
                        onClick = { viewModel.workbenchCode.value = "" },
                        modifier = Modifier.testTag("btn_workbench_clear")
                    ) {
                        Icon(Icons.Default.Clear, contentDescription = "Xóa hết", tint = ErrorRed)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        },
        containerColor = DarkBackground,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(12.dp)
        ) {
            // Quick Code Snippet Inserts
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val snippets = listOf(
                    "print(\"Hello Delta!\")" to "print(\"Hello Delta AI!\")\n",
                    "Orion GUI" to "local OrionLib = loadstring(game:HttpGet('https://raw.githubusercontent.com/shlexware/Orion/main/source'))()\n",
                    "task.wait()" to "task.wait(1.0)\n",
                    "pcall()" to "pcall(function()\n    -- Code safe execution\nend)\n",
                    "game:GetService" to "local Players = game:GetService(\"Players\")\n"
                )

                items(snippets) { (label, snippet) ->
                    SuggestionChip(
                        onClick = { viewModel.workbenchCode.value = code + "\n" + snippet },
                        label = { Text("+ $label", fontSize = 11.sp) },
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = DarkSurface,
                            labelColor = CyberVioletPrimary
                        ),
                        border = SuggestionChipDefaults.suggestionChipBorder(
                            enabled = true,
                            borderColor = DarkSurfaceVariant
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Code Editor Box
            Box(
                modifier = Modifier
                    .weight(0.55f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(CodeEditorBackground)
                    .border(1.dp, CyberVioletPrimary.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            ) {
                OutlinedTextField(
                    value = code,
                    onValueChange = { viewModel.workbenchCode.value = it },
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("input_workbench_editor"),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = Color(0xFFF1F5F9),
                        lineHeight = 18.sp
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Run Sandbox Action Button
            Button(
                onClick = { viewModel.executeWorkbenchScript() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_run_sandbox"),
                colors = ButtonDefaults.buttonColors(containerColor = CyberEmeraldSecondary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "CHẠY PHÂN TÍCH SANDBOX LUA",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Output Console Header & Log List
            Text(
                text = "CONSOLE OUTPUT LOGS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = CyberEmeraldSecondary,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(4.dp))

            Box(
                modifier = Modifier
                    .weight(0.45f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSurface)
                    .border(1.dp, DarkSurfaceVariant, RoundedCornerShape(12.dp))
                    .padding(8.dp)
            ) {
                if (outputResult == null) {
                    Text(
                        text = "Nhấn 'CHẠY PHÂN TÍCH SANDBOX LUA' để kiểm tra kết quả thực thi script...",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                } else {
                    val logs = outputResult!!.outputLog
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(logs) { log ->
                            val color = when (log.type) {
                                LogType.PRINT -> CyberEmeraldSecondary
                                LogType.SUCCESS -> Color(0xFF4ADE80)
                                LogType.ERROR -> ErrorRed
                                LogType.WARN -> Color(0xFFFBBF24)
                                LogType.SYSTEM -> CyberVioletPrimary
                                LogType.INFO -> Color.LightGray
                            }

                            Row(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "[${log.timestamp}] ",
                                    color = Color.DarkGray,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = log.text,
                                    color = color,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = if (log.type == LogType.ERROR || log.type == LogType.SUCCESS) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
