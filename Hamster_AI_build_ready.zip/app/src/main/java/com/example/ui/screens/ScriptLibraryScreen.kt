package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.SavedScriptEntity
import com.example.ui.theme.CyberEmeraldSecondary
import com.example.ui.theme.CyberVioletPrimary
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ErrorRed
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScriptLibraryScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val savedScripts by viewModel.savedScripts.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    var selectedTab by remember { mutableStateOf(0) } // 0: Thư Viện Đã Lưu, 1: Script Mẫu Sẵn Có

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Folder,
                            contentDescription = null,
                            tint = CyberVioletPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Thư Viện Script Lua",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        },
        containerColor = DarkBackground,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(12.dp)
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.searchQuery.value = it },
                placeholder = { Text("Tìm kiếm script theo tên, tag, từ khóa...", fontSize = 13.sp, color = Color.Gray) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = CyberVioletPrimary) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_search_scripts"),
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberVioletPrimary,
                    unfocusedBorderColor = DarkSurfaceVariant,
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = DarkSurface,
                contentColor = CyberVioletPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = CyberVioletPrimary
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Đã Lưu (${savedScripts.size})", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Script Mẫu Preset", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (selectedTab == 0) {
                if (savedScripts.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Chưa có script nào được lưu. Bạn có thể nhấn 'Lưu Thư Viện' trong khung chat AI hoặc Workbench!",
                            color = Color.Gray,
                            fontSize = 13.sp
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(savedScripts, key = { it.id }) { script ->
                            ScriptCardItem(
                                title = script.title,
                                description = script.description,
                                code = script.luaCode,
                                tags = script.tags,
                                isFavorite = script.isFavorite,
                                onFavoriteToggle = { viewModel.toggleFavoriteScript(script) },
                                onDelete = { viewModel.deleteScript(script.id) },
                                onCopy = { viewModel.copyToClipboard(it) },
                                onRunInWorkbench = { viewModel.loadCodeToWorkbench(it) },
                                onExport = { title, code -> viewModel.exportScriptToFile(title, code) }
                            )
                        }
                    }
                }
            } else {
                // Preset Built-in Templates
                val presets = getBuiltInPresetScripts()
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(presets) { preset ->
                        ScriptCardItem(
                            title = preset.title,
                            description = preset.description,
                            code = preset.luaCode,
                            tags = preset.tags,
                            isFavorite = true,
                            onFavoriteToggle = {},
                            onDelete = null,
                            onCopy = { viewModel.copyToClipboard(it) },
                            onRunInWorkbench = { viewModel.loadCodeToWorkbench(it) },
                            onExport = { title, code -> viewModel.exportScriptToFile(title, code) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ScriptCardItem(
    title: String,
    description: String,
    code: String,
    tags: String,
    isFavorite: Boolean,
    onFavoriteToggle: () -> Unit,
    onDelete: (() -> Unit)?,
    onCopy: (String) -> Unit,
    onRunInWorkbench: (String) -> Unit,
    onExport: (String, String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DarkSurface)
            .border(1.dp, DarkSurfaceVariant, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Code, contentDescription = null, tint = CyberEmeraldSecondary, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Row {
                IconButton(onClick = onFavoriteToggle, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Yêu thích",
                        tint = if (isFavorite) Color(0xFFFBBF24) else Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                }
                if (onDelete != null) {
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Xóa", tint = ErrorRed, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        if (description.isNotBlank()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = description, fontSize = 12.sp, color = Color.Gray)
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Code Preview Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF090D16))
                .padding(8.dp)
        ) {
            Text(
                text = code.lines().take(4).joinToString("\n"),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFFCBD5E1),
                maxLines = 4
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Tags: $tags",
                fontSize = 10.sp,
                color = CyberVioletPrimary,
                fontFamily = FontFamily.Monospace
            )

            Row {
                IconButton(onClick = { onRunInWorkbench(code) }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Workbench", tint = CyberEmeraldSecondary)
                }
                IconButton(onClick = { onCopy(code) }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = Color.White)
                }
                IconButton(onClick = { onExport(title, code) }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Download, contentDescription = "Tải .lua", tint = Color.White)
                }
            }
        }
    }
}

private fun getBuiltInPresetScripts(): List<SavedScriptEntity> {
    return listOf(
        SavedScriptEntity(
            id = "preset_1",
            title = "Delta Orion GUI Mobile Hub",
            description = "Bộ giao diện Orion Library chuẩn cho Delta Executor di động có Toggle & Slider",
            luaCode = """
-- Delta Orion Mobile GUI Hub
local OrionLib = loadstring(game:HttpGet('https://raw.githubusercontent.com/shlexware/Orion/main/source'))()
local Window = OrionLib:MakeWindow({Name = "Delta Script Hub v3.5", HidePremium = false, SaveConfig = true, ConfigFolder = "DeltaConfig"})

local Tab = Window:MakeTab({Name = "Chức Năng", Icon = "rbxassetid://4483345998", PremiumOnly = false})

Tab:AddButton({
    Name = "Bật Auto Farm",
    Callback = function()
        print("[DELTA AI]: Đã kích hoạt Auto Farm!")
    end
})

Tab:AddSlider({
    Name = "Tốc Độ Di Chuyển",
    Min = 16, Max = 250, Default = 50, Color = Color3.fromRGB(168, 85, 247), Increment = 1, ValueName = "Speed",
    Callback = function(Value)
        if game.Players.LocalPlayer.Character then
            game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = Value
        end
    end
})

OrionLib:Init()
            """.trimIndent(),
            tags = "Delta, Orion, Mobile, GUI",
            isFavorite = true
        ),
        SavedScriptEntity(
            id = "preset_2",
            title = "Rayfield UI Script Engine",
            description = "Thư viện Rayfield UI hiện đại với hệ thống Key System tích hợp",
            luaCode = """
-- Rayfield UI Delta Preset
local Rayfield = loadstring(game:HttpGet('https://sirius.menu/rayfield'))()
local Window = Rayfield:CreateWindow({
   Name = "Rayfield Hub Delta",
   LoadingTitle = "Đang tải Script Delta...",
   LoadingSubtitle = "bởi Delta Lua AI",
   ConfigurationSaving = { Enabled = true, FolderName = nil, FileName = "DeltaConfig" }
})

local MainTab = Window:CreateTab("Trang Chủ", 4483345998)
MainTab:CreateButton({
   Name = "Cập nhật nhân vật",
   Callback = function()
      print("Đã cập nhật chỉ số!")
   end,
})
            """.trimIndent(),
            tags = "Rayfield, KeySystem, GUI",
            isFavorite = true
        ),
        SavedScriptEntity(
            id = "preset_3",
            title = "Anti-AFK Safe Anti-Disconnect",
            description = "Tự động chống bị văng do treo máy lâu (AFK Kick) trên client điện thoại",
            luaCode = """
-- Anti-AFK Anti-Kick Script
local VirtualUser = game:GetService("VirtualUser")
game:GetService("Players").LocalPlayer.Idled:Connect(function()
    VirtualUser:CaptureController()
    VirtualUser:ClickButton2(Vector2.new())
    print("[DELTA AI]: Đã tự động kích hoạt chống AFK!")
end)
print("✓ Anti-AFK đã sẵn sàng bảo vệ phiên chơi!")
            """.trimIndent(),
            tags = "AntiAFK, Utility, Auto",
            isFavorite = true
        )
    )
}
