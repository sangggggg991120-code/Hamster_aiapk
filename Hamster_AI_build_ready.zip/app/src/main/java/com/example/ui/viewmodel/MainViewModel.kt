package com.example.ui.viewmodel

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Environment
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.AiMemoryEntity
import com.example.data.local.entity.ChatMessageEntity
import com.example.data.local.entity.ChatSessionEntity
import com.example.data.local.entity.SavedScriptEntity
import com.example.data.repository.ScriptAiRepository
import com.example.engine.ExecutionResult
import com.example.engine.LuaInterpreterEngine
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ScriptAiRepository(application)

    val allSessions: StateFlow<List<ChatSessionEntity>> = repository.allSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentSessionId = MutableStateFlow<String?>(null)
    val currentSystemMode = MutableStateFlow("DELTA_ROBLOX")
    val isGenerating = MutableStateFlow(false)

    @OptIn(ExperimentalCoroutinesApi::class)
    val currentMessages: StateFlow<List<ChatMessageEntity>> = currentSessionId.flatMapLatest { sessionId ->
        if (sessionId != null) repository.getMessagesForSession(sessionId)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Saved Scripts
    val searchQuery = MutableStateFlow("")
    @OptIn(ExperimentalCoroutinesApi::class)
    val savedScripts: StateFlow<List<SavedScriptEntity>> = searchQuery.flatMapLatest { query ->
        if (query.isBlank()) repository.allSavedScripts
        else repository.searchSavedScripts(query)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // AI Memories
    val memories: StateFlow<List<AiMemoryEntity>> = repository.allMemories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Lua Workbench Editor & Execution Engine
    val workbenchCode = MutableStateFlow("""
-- Welcome to Delta Lua AI Workbench
-- Nhấn 'Chạy Sandbox' để kiểm tra script trực tiếp trên thiết bị
local DeltaHub = {}

function DeltaHub.Init()
    print("🚀 Initializing Delta Executor Environment...")
    task.wait(0.5)
    print("✓ LocalPlayer: " .. (game.Players.LocalPlayer and game.Players.LocalPlayer.Name or "Player1"))
    print("✓ Speed set to 50")
end

DeltaHub.Init()
    """.trimIndent())

    val workbenchOutput = MutableStateFlow<ExecutionResult?>(null)

    init {
        // Automatically ensure at least 1 session exists or create one
        viewModelScope.launch {
            allSessions.collect { sessions ->
                if (sessions.isEmpty() && currentSessionId.value == null) {
                    val newSession = repository.createNewSession("Chat Script Delta", "DELTA_ROBLOX")
                    currentSessionId.value = newSession.id
                } else if (currentSessionId.value == null && sessions.isNotEmpty()) {
                    currentSessionId.value = sessions.first().id
                }
            }
        }
    }

    fun selectSession(sessionId: String) {
        currentSessionId.value = sessionId
    }

    fun createNewSession(title: String = "Chat Script Mới") {
        viewModelScope.launch {
            val session = repository.createNewSession(title, currentSystemMode.value)
            currentSessionId.value = session.id
        }
    }

    fun deleteSession(sessionId: String) {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            if (currentSessionId.value == sessionId) {
                currentSessionId.value = allSessions.value.firstOrNull { it.id != sessionId }?.id
            }
        }
    }

    fun sendMessage(promptText: String) {
        if (promptText.isBlank() || isGenerating.value) return
        val sessionId = currentSessionId.value ?: return

        viewModelScope.launch {
            isGenerating.value = true
            try {
                repository.sendMessage(sessionId, promptText, currentSystemMode.value)
            } catch (e: Exception) {
                showToast("Lỗi: ${e.message}")
            } finally {
                isGenerating.value = false
            }
        }
    }

    fun executeWorkbenchScript() {
        viewModelScope.launch {
            val code = workbenchCode.value
            val result = LuaInterpreterEngine.executeLuaScript(code)
            workbenchOutput.value = result
        }
    }

    fun loadCodeToWorkbench(code: String) {
        workbenchCode.value = code
        showToast("Đã chuyển code sang Tab Workbench!")
    }

    fun saveScriptToLibrary(title: String, description: String, code: String, tags: String) {
        viewModelScope.launch {
            repository.saveScript(title, description, code, tags)
            showToast("Đã lưu script vào thư viện!")
        }
    }

    fun toggleFavoriteScript(script: SavedScriptEntity) {
        viewModelScope.launch {
            repository.toggleFavoriteScript(script)
        }
    }

    fun deleteScript(id: String) {
        viewModelScope.launch {
            repository.deleteScript(id)
            showToast("Đã xóa script khỏi thư viện!")
        }
    }

    fun addAiMemory(title: String, detail: String, category: String) {
        viewModelScope.launch {
            repository.addMemory(title, detail, category)
            showToast("Đã ghi nhớ vào bộ nhớ AI!")
        }
    }

    fun toggleMemoryActive(memory: AiMemoryEntity) {
        viewModelScope.launch {
            repository.toggleMemoryActive(memory)
        }
    }

    fun deleteMemory(id: String) {
        viewModelScope.launch {
            repository.deleteMemory(id)
            showToast("Đã xóa khỏi bộ nhớ AI!")
        }
    }

    fun copyToClipboard(text: String) {
        val clipboard = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Lua Script", text)
        clipboard.setPrimaryClip(clip)
        showToast("Đã sao chép vào khay nhớ tạm!")
    }

    fun exportScriptToFile(title: String, code: String) {
        try {
            val fileName = "${title.replace(" ", "_").lowercase()}.lua"
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val scriptFile = File(downloadsDir, fileName)
            scriptFile.writeText(code)
            showToast("Đã tải xuống file: ${scriptFile.name}")
        } catch (e: Exception) {
            showToast("Không thể ghi file: ${e.message}")
        }
    }

    private fun showToast(msg: String) {
        Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
    }
}
