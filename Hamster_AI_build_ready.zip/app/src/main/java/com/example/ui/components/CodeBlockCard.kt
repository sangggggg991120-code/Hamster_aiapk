package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CodeEditorBackground
import com.example.ui.theme.CyberEmeraldSecondary
import com.example.ui.theme.CyberVioletPrimary
import com.example.ui.theme.DarkSurfaceVariant

@Composable
fun CodeBlockCard(
    code: String,
    language: String = "lua",
    onCopy: (String) -> Unit,
    onRunInWorkbench: (String) -> Unit,
    onSaveToLibrary: (title: String, desc: String, code: String, tags: String) -> Unit,
    onExportFile: (title: String, code: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showSaveDialog by remember { mutableStateOf(false) }
    var scriptTitle by remember { mutableStateOf("Script Delta ${System.currentTimeMillis() % 1000}") }
    var scriptDesc by remember { mutableStateOf("Được tạo tự động bởi Delta Lua AI") }
    var scriptTags by remember { mutableStateOf("Delta, Roblox, Mobile") }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CodeEditorBackground)
            .border(1.dp, CyberVioletPrimary.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
    ) {
        // Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurfaceVariant)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(CyberVioletPrimary.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = language.uppercase(),
                        color = CyberVioletPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "${code.lines().size} lines",
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }

            Row {
                IconButton(
                    onClick = { onRunInWorkbench(code) },
                    modifier = Modifier.testTag("btn_run_workbench")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Chạy Workbench",
                        tint = CyberEmeraldSecondary
                    )
                }
                IconButton(
                    onClick = { showSaveDialog = true },
                    modifier = Modifier.testTag("btn_save_library")
                ) {
                    Icon(
                        imageVector = Icons.Default.Save,
                        contentDescription = "Lưu thư viện",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                IconButton(
                    onClick = { onCopy(code) },
                    modifier = Modifier.testTag("btn_copy_code")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Sao chép code",
                        tint = Color.White
                    )
                }
                IconButton(
                    onClick = { onExportFile(scriptTitle, code) },
                    modifier = Modifier.testTag("btn_export_code")
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "Tải file .lua",
                        tint = Color.White
                    )
                }
            }
        }

        // Code Content
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Text(
                text = code,
                color = Color(0xFFE2E8F0),
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 18.sp
            )
        }
    }

    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Lưu Script Vào Thư Viện", color = Color.White) },
            text = {
                Column {
                    OutlinedTextField(
                        value = scriptTitle,
                        onValueChange = { scriptTitle = it },
                        label = { Text("Tên Script") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CyberVioletPrimary),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = scriptDesc,
                        onValueChange = { scriptDesc = it },
                        label = { Text("Mô tả ngắn") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CyberVioletPrimary),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = scriptTags,
                        onValueChange = { scriptTags = it },
                        label = { Text("Thẻ (Tags)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = CyberVioletPrimary),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSaveToLibrary(scriptTitle, scriptDesc, code, scriptTags)
                        showSaveDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberVioletPrimary)
                ) {
                    Text("Lưu Ngay")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("Hủy", color = Color.Gray)
                }
            },
            containerColor = DarkSurfaceVariant
        )
    }
}
