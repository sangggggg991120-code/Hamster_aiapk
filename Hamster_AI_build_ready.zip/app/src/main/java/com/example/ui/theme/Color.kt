package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberVioletPrimary = Color(0xFFC084FC)
val CyberEmeraldSecondary = Color(0xFF34D399)
val CyberCyanTertiary = Color(0xFF38BDF8)

val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF131B2E)
val DarkSurfaceVariant = Color(0xFF1E293B)
val CodeEditorBackground = Color(0xFF090D16)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val AccentGold = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFF87171)

