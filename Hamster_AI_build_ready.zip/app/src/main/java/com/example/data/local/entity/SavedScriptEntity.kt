package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "saved_scripts")
data class SavedScriptEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String,
    val luaCode: String,
    val tags: String, // e.g. "Delta, GUI, AutoFarm"
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
