package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "ai_memories")
data class AiMemoryEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val detail: String,
    val category: String = "GUIDELINE", // "GUIDELINE", "SCRIPT_TEMPLATE", "PREFERENCE"
    val isActive: Boolean = true,
    val updatedAt: Long = System.currentTimeMillis()
)
