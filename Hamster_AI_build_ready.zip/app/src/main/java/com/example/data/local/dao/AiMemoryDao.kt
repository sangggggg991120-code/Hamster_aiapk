package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.AiMemoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AiMemoryDao {
    @Query("SELECT * FROM ai_memories ORDER BY updatedAt DESC")
    fun getAllMemories(): Flow<List<AiMemoryEntity>>

    @Query("SELECT * FROM ai_memories WHERE isActive = 1 ORDER BY updatedAt DESC")
    suspend fun getActiveMemories(): List<AiMemoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: AiMemoryEntity)

    @Update
    suspend fun updateMemory(memory: AiMemoryEntity)

    @Query("DELETE FROM ai_memories WHERE id = :id")
    suspend fun deleteMemoryById(id: String)
}
