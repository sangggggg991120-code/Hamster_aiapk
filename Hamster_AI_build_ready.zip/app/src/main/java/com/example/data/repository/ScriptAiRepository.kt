package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AiMemoryEntity
import com.example.data.local.entity.ChatMessageEntity
import com.example.data.local.entity.ChatSessionEntity
import com.example.data.local.entity.SavedScriptEntity
import com.example.data.remote.Content
import com.example.data.remote.GenerateContentRequest
import com.example.data.remote.GenerationConfig
import com.example.data.remote.Part
import com.example.data.remote.RetrofitClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

class ScriptAiRepository(context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val chatDao = db.chatDao()
    private val savedScriptDao = db.savedScriptDao()
    private val aiMemoryDao = db.aiMemoryDao()

    // --- Chat Sessions ---
    val allSessions: Flow<List<ChatSessionEntity>> = chatDao.getAllSessions()

    suspend fun createNewSession(title: String = "Chat Script Mới", mode: String = "DELTA_ROBLOX"): ChatSessionEntity = withContext(Dispatchers.IO) {
        val session = ChatSessionEntity(
            title = title,
            systemPromptMode = mode
        )
        chatDao.insertSession(session)
        session
    }

    suspend fun getSessionById(sessionId: String): ChatSessionEntity? = withContext(Dispatchers.IO) {
        chatDao.getSessionById(sessionId)
    }

    suspend fun updateSessionTitle(sessionId: String, newTitle: String) = withContext(Dispatchers.IO) {
        val session = chatDao.getSessionById(sessionId)
        if (session != null) {
            chatDao.updateSession(session.copy(title = newTitle, updatedAt = System.currentTimeMillis()))
        }
    }

    suspend fun deleteSession(sessionId: String) = withContext(Dispatchers.IO) {
        chatDao.deleteMessagesBySessionId(sessionId)
        chatDao.deleteSessionById(sessionId)
    }

    // --- Messages ---
    fun getMessagesForSession(sessionId: String): Flow<List<ChatMessageEntity>> =
        chatDao.getMessagesForSession(sessionId)

    suspend fun sendMessage(
        sessionId: String,
        userPrompt: String,
        systemMode: String
    ): ChatMessageEntity = withContext(Dispatchers.IO) {
        // 1. Save User Message
        val userMessage = ChatMessageEntity(
            sessionId = sessionId,
            sender = "user",
            content = userPrompt
        )
        chatDao.insertMessage(userMessage)

        // 2. Fetch Active Memories to inject as system context
        val activeMemories = aiMemoryDao.getActiveMemories()
        val memoryText = if (activeMemories.isNotEmpty()) {
            "\n\n[BỘ NHỚ AI TỰ ĐỘNG - GHI NHỚ NGƯỜI DÙNG]:\n" + activeMemories.joinToString("\n") { "- ${it.title}: ${it.detail}" }
        } else ""

        // 3. Build System Instruction based on systemMode
        val systemPromptText = when (systemMode) {
            "DELTA_ROBLOX" -> """
                Bạn là Chuyên gia AI Cao cấp về Lập trình Script Lua và Delta Executor Roblox Mobile.
                Nhiệm vụ của bạn:
                - Viết code Lua hoàn chỉnh, sạch sẽ, tối ưu hóa cho Delta Mobile Executor và Roblox client.
                - Tự động tích hợp GUI đẹp mắt (như Orion Library, Rayfield UI, Fluent UI hoặc Custom Mobile Hub).
                - Giải thích cách hoạt động của script rõ ràng, bằng tiếng Việt thân thiện, dễ hiểu.
                - Hỗ trợ sửa lỗi bug, tối ưu tốc độ và cấu trúc code.
                - Hãy bao bọc toàn bộ code Lua trong khối markdown ```lua ... ```.
            """.trimIndent() + memoryText

            "LUA_UNIVERSAL" -> """
                Bạn là Trợ lý AI Chuyên viết Script Lua đa nền tảng (Lua 5.1/5.4, LÖVE2D, Game Engines, Mobile Scripts).
                - Viết code Lua mạnh mẽ, xử lý chuỗi, bảng (tables), I/O, coroutines và thuật toán tối ưu.
                - Giải thích chi tiết các hàm và tham số bằng tiếng Việt.
                - Luôn bao bọc code trong ```lua ... ```.
            """.trimIndent() + memoryText

            else -> """
                Bạn là Trợ lý AI Lập trình Script chuyên nghiệp hỗ trợ viết code Lua, Delta Executor, game scripting và di động.
                Hãy trả lời bằng tiếng Việt chi tiết, thân thiện và tạo code Lua chất lượng cao trong khối ```lua ... ```.
            """.trimIndent() + memoryText
        }

        // 4. Build Conversation History for Gemini API
        val pastMessages = chatDao.getMessagesListForSession(sessionId)
        val contentsList = mutableListOf<Content>()

        // Limit context to last 12 messages for efficiency
        val recentMessages = pastMessages.takeLast(12)
        for (msg in recentMessages) {
            val roleName = if (msg.sender == "user") "user" else "model"
            contentsList.add(
                Content(
                    role = roleName,
                    parts = listOf(Part(text = msg.content))
                )
            )
        }

        // 5. Call Gemini API
        val apiKey = RetrofitClient.getApiKey()
        var aiResponseText: String
        var extractedCode: String? = null

        try {
            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                // Fallback smart offline response if API Key is not set yet in secrets
                aiResponseText = generateOfflineFallbackResponse(userPrompt, systemMode)
            } else {
                val request = GenerateContentRequest(
                    contents = contentsList,
                    systemInstruction = Content(parts = listOf(Part(text = systemPromptText))),
                    generationConfig = GenerationConfig(temperature = 0.7f, topP = 0.95f)
                )

                val response = RetrofitClient.service.generateContent(apiKey, request)
                val responseContent = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (!responseContent.isNullOrBlank()) {
                    aiResponseText = responseContent
                } else if (response.error != null) {
                    aiResponseText = "⚠️ Lỗi Gemini API: ${response.error.message ?: "Không nhận được phản hồi"}"
                } else {
                    aiResponseText = generateOfflineFallbackResponse(userPrompt, systemMode)
                }
            }
        } catch (e: Exception) {
            aiResponseText = "⚠️ Lỗi kết nối mạng: ${e.localizedMessage ?: e.message}\n\nĐã chuyển sang chế độ AI trợ lý cục bộ:\n\n" + generateOfflineFallbackResponse(userPrompt, systemMode)
        }

        // Extract code snippet if present in markdown ```lua ... ```
        val codeRegex = Regex("```(?:lua)?\\s*([\\s\\S]*?)```", RegexOption.IGNORE_CASE)
        val match = codeRegex.find(aiResponseText)
        if (match != null) {
            extractedCode = match.groupValues[1].trim()
        }

        // 6. Save Assistant Response Message to Room DB
        val assistantMessage = ChatMessageEntity(
            sessionId = sessionId,
            sender = "assistant",
            content = aiResponseText,
            codeSnippet = extractedCode
        )
        chatDao.insertMessage(assistantMessage)

        // Update session timestamp & auto-title if first user message
        val currentSession = chatDao.getSessionById(sessionId)
        if (currentSession != null) {
            val autoTitle = if (currentSession.title == "Chat Script Mới" && userPrompt.isNotBlank()) {
                userPrompt.take(30) + "..."
            } else currentSession.title
            chatDao.updateSession(currentSession.copy(title = autoTitle, updatedAt = System.currentTimeMillis()))
        }

        assistantMessage
    }

    private fun generateOfflineFallbackResponse(prompt: String, mode: String): String {
        val p = prompt.lowercase()
        return when {
            p.contains("gui") || p.contains("orion") || p.contains("rayfield") || p.contains("delta") -> """
                Dưới đây là Script mẫu GUI Orion / Delta Executor chuyên nghiệp cho Roblox Mobile:

                ```lua
                -- Delta Executor Mobile GUI Template
                local OrionLib = loadstring(game:HttpGet('https://raw.githubusercontent.com/shlexware/Orion/main/source'))()
                local Window = OrionLib:MakeWindow({
                    Name = "Delta Script Hub v3.5",
                    HidePremium = false,
                    SaveConfig = true,
                    ConfigFolder = "DeltaConfig"
                })

                local Tab = Window:MakeTab({
                    Name = "Tính năng chính",
                    Icon = "rbxassetid://4483345998",
                    PremiumOnly = false
                })

                Tab:AddButton({
                    Name = "Bật Auto Farm Base",
                    Callback = function()
                        print("[DELTA AI]: Đã bật chế độ Auto Farm!")
                        game:GetService("StarterGui"):SetCore("SendNotification", {
                            Title = "Delta AI Script",
                            Text = "Đã khởi chạy tác vụ thành công!",
                            Duration = 3
                        })
                    end
                })

                Tab:AddSlider({
                    Name = "Tốc độ di chuyển (WalkSpeed)",
                    Min = 16,
                    Max = 200,
                    Default = 50,
                    Color = Color3.fromRGB(168, 85, 247),
                    Increment = 1,
                    ValueName = "Speed",
                    Callback = function(Value)
                        if game.Players.LocalPlayer.Character then
                            game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = Value
                        end
                    end
                })

                OrionLib:Init()
                print("Delta GUI Loaded Successfully!")
                ```

                💡 **Hướng dẫn:** Bạn có thể nhấn nút **Chạy Thử Lua** hoặc **Sao chép Code** ở góc trên script để kiểm tra!
            """.trimIndent()

            p.contains("farm") || p.contains("autofarm") || p.contains("loop") -> """
                Dưới đây là Script Lua Auto Farm Loop an toàn có bảo vệ ngắt kết nối (Anti-Crash Loop):

                ```lua
                -- Auto Farm Loop với task.wait() safe execution
                local isFarming = true
                local LocalPlayer = game.Players.LocalPlayer

                task.spawn(function()
                    while isFarming do
                        task.wait(0.5)
                        pcall(function()
                            print("[FARM]: Đang cập nhật trạng thái nhiệm vụ...")
                            -- Thêm logic thu thập coin / tiêu diệt mob ở đây
                        end)
                    end
                end)

                print("✓ Đã kích hoạt Auto Farm Loop thành công!")
                ```

                💡 Ghi chú: Sử dụng `task.wait()` và `pcall()` để tránh bị treo client hoặc văng ứng dụng trên điện thoại di động!
            """.trimIndent()

            else -> """
                Dưới đây là cấu trúc Script Lua đa dụng tương thích hoàn hảo với mọi môi trường & Delta Executor:

                ```lua
                -- Script Lua Tự động hóa đa nền tảng
                local Utility = {}

                function Utility.Notify(title, text)
                    print(string.format("[%s]: %s", title, text))
                end

                function Utility.CalculateMultiplier(baseValue, bonusRate)
                    return baseValue * (1 + bonusRate)
                end

                -- Khởi chạy script
                Utility.Notify("Delta AI Assistant", "Đã khởi tạo Script Lua thành công!")
                local total = Utility.CalculateMultiplier(100, 0.5)
                print("Kết quả tính toán:", total)
                ```

                🚀 Bạn có thể nhấn nút **Chạy Thử Lua** ở tab Workbench để thực thi script này trong Sandbox!
            """.trimIndent()
        }
    }

    // --- Saved Scripts ---
    val allSavedScripts: Flow<List<SavedScriptEntity>> = savedScriptDao.getAllScripts()

    fun searchSavedScripts(query: String): Flow<List<SavedScriptEntity>> =
        savedScriptDao.searchScripts(query)

    suspend fun saveScript(title: String, description: String, luaCode: String, tags: String) = withContext(Dispatchers.IO) {
        val script = SavedScriptEntity(
            title = title,
            description = description,
            luaCode = luaCode,
            tags = tags
        )
        savedScriptDao.insertScript(script)
    }

    suspend fun toggleFavoriteScript(script: SavedScriptEntity) = withContext(Dispatchers.IO) {
        savedScriptDao.updateScript(script.copy(isFavorite = !script.isFavorite))
    }

    suspend fun deleteScript(id: String) = withContext(Dispatchers.IO) {
        savedScriptDao.deleteScriptById(id)
    }

    // --- AI Memories ---
    val allMemories: Flow<List<AiMemoryEntity>> = aiMemoryDao.getAllMemories()

    suspend fun addMemory(title: String, detail: String, category: String = "GUIDELINE") = withContext(Dispatchers.IO) {
        val memory = AiMemoryEntity(title = title, detail = detail, category = category)
        aiMemoryDao.insertMemory(memory)
    }

    suspend fun toggleMemoryActive(memory: AiMemoryEntity) = withContext(Dispatchers.IO) {
        aiMemoryDao.updateMemory(memory.copy(isActive = !memory.isActive))
    }

    suspend fun deleteMemory(id: String) = withContext(Dispatchers.IO) {
        aiMemoryDao.deleteMemoryById(id)
    }
}
