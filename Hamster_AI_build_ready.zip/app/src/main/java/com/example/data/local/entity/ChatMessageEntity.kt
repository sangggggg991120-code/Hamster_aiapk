package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val sessionId: String,
    val sender: String, // "user", "assistant", "system"
    val content: String,
    val codeSnippet: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
