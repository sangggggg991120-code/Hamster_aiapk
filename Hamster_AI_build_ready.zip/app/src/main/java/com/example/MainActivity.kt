package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.AiMemoryScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.LuaWorkbenchScreen
import com.example.ui.screens.ScriptLibraryScreen
import com.example.ui.theme.CyberEmeraldSecondary
import com.example.ui.theme.CyberVioletPrimary
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DeltaLuaAiTheme
import com.example.ui.viewmodel.MainViewModel

sealed class Screen(val route: String, val title: String, val icon: ImageVector, val tag: String) {
    object Chat : Screen("chat", "Trợ Lý AI", Icons.Default.AutoAwesome, "nav_chat")
    object Workbench : Screen("workbench", "Workbench", Icons.Default.Terminal, "nav_workbench")
    object Library : Screen("library", "Thư Viện", Icons.Default.Folder, "nav_library")
    object Memory : Screen("memory", "Bộ Nhớ AI", Icons.Default.Memory, "nav_memory")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            DeltaLuaAiTheme {
                val mainViewModel: MainViewModel = viewModel()
                MainAppStructure(viewModel = mainViewModel)
            }
        }
    }
}

@Composable
fun MainAppStructure(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val items = listOf(
        Screen.Chat,
        Screen.Workbench,
        Screen.Library,
        Screen.Memory
    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                tonalElevation = 8.dp
            ) {
                items.forEach { screen ->
                    val isSelected = currentRoute == screen.route
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = screen.icon,
                                contentDescription = screen.title,
                                tint = if (isSelected) CyberVioletPrimary else Color.Gray
                            )
                        },
                        label = {
                            Text(
                                text = screen.title,
                                fontSize = 11.sp,
                                color = if (isSelected) CyberVioletPrimary else Color.Gray
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = CyberVioletPrimary.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag(screen.tag)
                    )
                }
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Chat.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Chat.route) {
                ChatScreen(viewModel = viewModel)
            }
            composable(Screen.Workbench.route) {
                LuaWorkbenchScreen(viewModel = viewModel)
            }
            composable(Screen.Library.route) {
                ScriptLibraryScreen(viewModel = viewModel)
            }
            composable(Screen.Memory.route) {
                AiMemoryScreen(viewModel = viewModel)
            }
        }
    }
}
